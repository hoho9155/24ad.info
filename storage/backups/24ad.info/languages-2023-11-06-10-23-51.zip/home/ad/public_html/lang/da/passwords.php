<?php 

return [
    'password' => 'Adgangskoder skal være på mindst otte tegn og matche bekræftelsen.',
    'reset' => 'Din adgangskode er blevet nulstillet!',
    'sent' => 'Vi har e-mailet dit link til nulstilling af adgangskode!',
    'token' => 'Dette token til nulstilling af adgangskode er ugyldigt.',
    'user' => 'Vi kan ikke finde en bruger med den e-mailadresse.',
    'throttled' => 'Please wait before retrying.',
];
