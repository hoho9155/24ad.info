<?php 

return [
    'password' => 'Las contraseñas deben coincidir y contener al menos 8 caracteres',
    'reset' => '¡Tu contraseña ha sido restablecida!',
    'sent' => '¡Te hemos enviado por correo el enlace para restablecer tu contraseña!',
    'token' => 'El token de recuperación de contraseña es inválido.',
    'user' => 'No podemos encontrar ningún usuario con ese correo electrónico.',
    'throttled' => 'Please wait before retrying.',
];
