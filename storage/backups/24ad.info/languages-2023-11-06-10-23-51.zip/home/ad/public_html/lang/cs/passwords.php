<?php 

return [
    'password' => 'Hesla musí mít alespoň osm znaků a odpovídat potvrzení.',
    'reset' => 'Vaše heslo bylo resetováno!',
    'sent' => 'Poslali jsme vám e-mailem odkaz pro obnovení hesla!',
    'token' => 'Tento token pro resetování hesla je neplatný.',
    'user' => 'Nemůžeme najít uživatele s touto e-mailovou adresou.',
    'throttled' => 'Please wait before retrying.',
];
