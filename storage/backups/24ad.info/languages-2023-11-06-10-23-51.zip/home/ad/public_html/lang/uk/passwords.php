<?php

return [
    
    /*
    |--------------------------------------------------------------------------
    | Password Reminder Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */
    
    'password' => 'Пароль повинен містити принаймні вісім символів та відповідати підтвердженню.',
    'reset' => 'Ваш пароль був скинутий!',
    'sent' => 'Ми відправили електронного листа з посиланням для скидання пароля!',
    'token' => 'Цей токен для скидання пароля недійсний.',
    'user' => 'Ми не можемо знайти користувача за цим електронною адресою.',
    
];
