<?php

return [
	'Whoops!' => 'Ой!',
	'Hello!' => 'Привіт!',
	'Regards' => 'З повагою',
	'having_trouble_on_link' => 'Якщо у вас виникли проблеми з натисканням кнопки ":actionText", скопіюйте та вставте нижче URL-адресу в вашому веб-переглядачі:',
	'All rights reserved.' => 'Усі права захищені.',
	'footer_salutation' => 'З повагою,<br>:appName',
	'mail_footer_content' => 'Продавайте і купуйте поблизу. Просто, швидко і ефективно.',
	'email_example_title' => 'Пошта :appName була успішно налаштована',
	'e-mail_example_content_1' => 'Пошта була успішно налаштована!',
	'e-mail_example_content_2' => 'Цей лист надіслано для перевірки нових облікових даних для :appName. Оскільки ви отримали цей лист, налаштування пошти пройшло успішно, і цей лист можна проігнорувати.',
	'email_verification_title' => 'Будь ласка, підтвердіть свою адресу електронної пошти',
	'email_verification_action' => 'Підтвердити адресу електронної пошти',
	'email_verification_content_1' => 'Привіт, :userName!',
	'email_verification_content_2' => 'Клацніть кнопку нижче, щоб підтвердити свою адресу електронної пошти',
	'email_verification_content_3' => 'Ви отримали цей лист, оскільки недавно створили новий обліковий запис на :appName або додали нову адресу електронної пошти. Якщо це не ви, проігноруйте цей лист.',
	'post_activated_title' => 'Ваше оголошення було активовано',
	'post_activated_content_1' => 'Привіт,',
	'post_activated_content_2' => 'Ваше оголошення <a href=":postUrl">:title</a> було активовано.',
	'post_activated_content_3' => 'Найближчим часом воно буде перевірено нашим адміністратором для публікації в мережі.',
	'post_activated_content_4' => 'Ви отримали цей лист, оскільки недавно створили новий запис на :appName або додали нову адресу електронної пошти. Якщо це не ви, проігноруйте цей лист.',
	'post_reviewed_title' => 'Ваше оголошення зараз онлайн',
	'post_reviewed_content_1' => 'Привіт,',
	'post_reviewed_content_2' => 'Ваше оголошення <a href=":postUrl">:title</a> зараз на сайті.',
	'post_reviewed_content_3' => 'Ви отримали цей лист, оскільки недавно створили новий запис на :appName або додали нову адресу електронної пошти. Якщо це не ви, проігноруйте цей лист.',
	'post_republished_title' => 'Ваше оголошення було опубліковано знову',
	'post_republished_content_1' => 'Привіт,',
	'post_republished_content_2' => 'Ваше оголошення <a href=":postUrl">:title</a> було успішно опубліковано знову.',
	'post_republished_content_3' => 'Ви отримали цей лист, оскільки недавно створили новий запис на :appName або додали нову адресу електронної пошти. Якщо це не ви, проігноруйте цей лист.',
	'post_deleted_title' => 'Ваше оголошення було видалено',
	'post_deleted_content_1' => 'Привіт,',
	'post_deleted_content_2' => 'Ваше оголошення ":title" було видалено з :appName о :now.',
	'post_deleted_content_3' => 'Дякуємо за вашу довіру, і до зустрічі найближчим часом.',
	'post_deleted_content_4' => 'PS: Це автоматичне повідомлення електронної пошти, будь ласка, не відповідайте на нього.',
	'post_seller_contacted_title' => 'Ваше оголошення ":title" на :appName',
	'post_seller_contacted_content_1' => '<strong>Контактна інформація:</strong>
		<br>Ім\'я: :name
		<br>Адреса електронної пошти: :email
		<br>Номер телефону: :phone',
	'post_seller_contacted_content_2' => 'Цей лист був надісланий вам щодо оголошення ":title", яке ви опублікували на :appName : <a href=":postUrl">:postUrl</a>',	'post_seller_contacted_content_3'  => 'NOTE: The person who contacted you do not know your email as you will not reply.',
	'post_seller_contacted_content_3' => 'Примітка: Особа, яка з вами зв\'язалася, не знає вашої електронної адреси і не повинна відповідати на неї.',
	'post_seller_contacted_content_4' => 'Завжди перевіряйте контактну інформацію (ім\'я, адреса і т. д.), щоб мати можливість зв\'язатися у випадку конфлікту. Загалом, обирайте особисту зустріч для продажу товару.',
	'post_seller_contacted_content_5' => 'Будьте обережні з привабливими пропозиціями! Уникайте запитів з-за кордону, коли ви маєте лише контактну електронну адресу. Уникайте переказу через Western Union або MoneyGram, якщо це запропоновано.',
	'post_seller_contacted_content_6' => 'Дякуємо за довіру і чекаємо на ваші нові оголошення найближчим часом.',
	//'post_seller_contacted_content_7' => 'Примітка: Це автоматичне електронне повідомлення, будь ласка, не відповідайте на нього.'
	// user_deleted
	'user_deleted_title' => 'Ваш обліковий запис було видалено за допомогою :appName',
	'user_deleted_content_1' => 'Привіт,',
	'user_deleted_content_2' => 'Ваш обліковий запис було видалено за допомогою <a href=":appUrl">:appName</a> у :now.',
	'user_deleted_content_3' => 'Дякуємо вам за довіру і чекаємо зустрічі найближчим часом.',
	'user_deleted_content_4' => 'Примітка: Це автоматичне електронне повідомлення, будь ласка, не відповідайте на нього.',
	// user_activated (new)
	'user_activated_title' => 'Ласкаво просимо до :appName!',
	'user_activated_content_1' => 'Ласкаво просимо до :appName, :userName!',
	'user_activated_content_2' => 'Ваш обліковий запис активовано.',
	'user_activated_content_3' => '<strong>Примітка від :appName Team:</strong>
	<br><br>1 - Завжди бережіться при взаємодії з оголошувачами, які відмовляються демонструвати товар або продукт для перевірки перед продажем або орендою.
	<br>2 - Ніколи не надсилайте гроші через Western Union або будь-які інші міжнародні перекази.
	<br><br>Якщо ви маєте сумніви щодо дійсності оголошувача, негайно звертайтеся до нас. Ми зможемо швидко реагувати на можливі проблеми і запобігти ризику для менш досвідчених користувачів.',
	'user_activated_content_4' => 'Ви отримали це повідомлення електронної пошти, так як недавно створили новий обліковий запис у :appName. Якщо це не ви, проігноруйте це повідомлення.',
	// reset_password
	'reset_password_title' => 'Скидання пароля вашого облікового запису',
	'reset_password_action' => 'Скинути пароль',
	'reset_password_content_1' => 'Ви отримали це повідомлення електронної пошти, оскільки ми отримали запит на скидання пароля вашого облікового запису.',
	'reset_password_content_2' => 'Термін дії посилання для скидання пароля закінчується через :expireTimeString.',
	'reset_password_content_3' => 'Якщо ви не надсилали запит на скидання пароля, вам не потрібно вживати жодних додаткових заходів.',
	// contact_form
	'contact_form_title' => 'Нове повідомлення від :appName',
	// post_report_sent
	'post_report_sent_title' => 'Відправлено нову скаргу на зловживання',
	'Listing URL' => 'Посилання на оголошення',
	// post_archived
	'post_archived_title' => 'Ваше оголошення було архівовано',
	'post_archived_content_1' => 'Вітаємо,',
	'post_archived_content_2' => 'Ваше оголошення ":title" було архівовано :appName в :now.',
	'post_archived_content_3' => 'Ви можете повторно опублікувати його, натиснувши тут: <a href=":repostUrl">:repostUrl</a>',
	'post_archived_content_4' => 'Якщо ви не вживаєте жодних заходів, оголошення буде остаточно видалено в :dateDel.',
	'post_archived_content_5' => 'Дякуємо за вашу довіру, і ми з нетерпінням чекаємо вас найближчим часом.',
	'post_archived_content_6' => 'Примітка: Це автоматичне електронне повідомлення, будь ласка, не відповідайте на нього.',
	// post_will_be_deleted
	'post_will_be_deleted_title' => 'Ваше оголошення буде видалено через :days днів',
	'post_will_be_deleted_content_1' => 'Вітаємо,',
	'post_will_be_deleted_content_2' => 'Ваше оголошення ":title" буде видалено через :days днів :appName.',
	'post_will_be_deleted_content_3' => 'Ви можете повторно опублікувати його, натиснувши тут: <a href=":repostUrl">:repostUrl</a>',
	'post_will_be_deleted_content_4' => 'Якщо ви не вживаєте жодних заходів, оголошення буде остаточно видалено в :dateDel.',
	'post_will_be_deleted_content_5' => 'Дякуємо за вашу довіру, і ми з нетерпінням чекаємо вас найближчим часом.',
	'post_will_be_deleted_content_6' => 'Примітка: Це автоматичне електронне повідомлення, будь ласка, не відповідайте на нього.',
	// post_notification
	'post_notification_title' => 'Нове оголошення',
	'post_notification_content_1' => 'Вітаємо, веб-мастер:',
	'post_notification_content_2' => 'Користувач :advertiserName розмістив нове оголошення.',
	'post_notification_content_3' => 'Заголовок оголошення: <a href=":postUrl">:title</a><br>Опубліковано в :now о :time',
	// user_notification
	'user_notification_title' => 'Нова реєстрація користувача',
	'user_notification_content_1' => 'Вітаємо, веб-мастер:',
	'user_notification_content_2' => ':name зареєструвався як новий користувач.',
	'user_notification_content_3' => 'Зареєстровано в :now о :time<br>Поле перевірки: :authField<br>Електронна пошта: :email<br>Телефон: :phone',
	// payment_sent
	'payment_sent_title' => 'Дякуємо за ваш платіж!',
	'payment_sent_content_1' => 'Вітаємо,',
	'payment_sent_content_2' => 'Ми отримали ваш платіж за оголошення "<a href=":postUrl">:title</a>".',
	'payment_sent_content_3' => 'Дякуємо вам!',
	// payment_notification
	'payment_notification_title' => 'Відправлено новий платіж',
	'payment_notification_content_1' => 'Вітаємо, веб-мастер:',
	'payment_notification_content_2' => 'Користувач :advertiserName відправив платіж за пакет, пов’язаний з оголошенням "<a href=":postUrl">:title</a>".',
	'payment_notification_content_3' => 'Деталі платежу
	<br><strong>Причина платежу:</strong> Оголошення #:adId - :packageName
	<br><strong>Сума:</strong> :amount :currency
	<br><strong>Спосіб оплати:</strong> :paymentMethodName',
	// payment_approved (new)
	'payment_approved_title' => 'Ваш платіж схвалено!',
	'payment_approved_content_1' => 'Вітаємо,',
	'payment_approved_content_2' => 'Ваш платіж за оголошення "<a href=":postUrl">:title</a>" було схвалено.',
	'payment_approved_content_3' => 'Дякуємо вам!',
	'payment_approved_content_4' => 'Деталі платежу
	<br><strong>Причина платежу:</strong> Оголошення #:adId - :packageName
	<br><strong>Сума:</strong> :amount :currency
	<br><strong>Спосіб оплати:</strong> :paymentMethodName',
	// reply_form
	'reply_form_title' => ':subject',
	'reply_form_content_1' => 'Вітаємо,',
	'reply_form_content_2' => '<strong>Ви отримали повідомлення від: :senderName. Перегляньте повідомлення нижче:</strong>',
	// generated_password
	'generated_password_title' => 'Ваш пароль',
	'generated_password_content_1' => 'Вітаємо, :userName!',
	'generated_password_content_2' => 'Ваш обліковий запис було створено.',
	'generated_password_verify_content_3' => 'Натисніть кнопку нижче, щоб підтвердити свою електронну адресу.',
	'generated_password_verify_action' => 'Підтвердити електронну адресу',
	'generated_password_content_4' => 'Ваш пароль: <strong>:randomPassword</strong>',
	'generated_password_login_action' => 'Увійти зараз!',
	'generated_password_content_6' => 'Ви отримали це електронне повідомлення, оскільки недавно створили обліковий запис в :appName або додали новий адресу електронної пошти. Якщо це були не ви, будь ласка, ігноруйте цей лист.',
];
