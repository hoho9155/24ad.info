<?php 

return [
    'password' => 'Heslá musia mať aspoň osem znakov a musia sa zhodovať s potvrdením.',
    'reset' => 'Vaše heslo bolo obnovené!',
    'sent' => 'Odkaz na obnovenie hesla sme vám poslali e-mailom!',
    'token' => 'Tento token na obnovenie hesla je neplatný.',
    'user' => 'Nemôžeme nájsť používateľa s touto e-mailovou adresou.',
    'throttled' => 'Please wait before retrying.',
];
