<?php 

return [
    'password' => 'Lozinke moraju imati najmanje osam znakova i odgovarati potvrdi.',
    'reset' => 'Vaša lozinka je resetirana!',
    'sent' => 'E-poštom smo vam poslali vezu za ponovno postavljanje lozinke!',
    'token' => 'Ovaj token za ponovno postavljanje zaporke nije valjan.',
    'user' => 'Ne možemo pronaći korisnika s tom adresom e-pošte.',
    'throttled' => 'Please wait before retrying.',
];
