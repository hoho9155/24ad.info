<?php 

return [
    'previous' => '«  Poprzedni',
    'next' => 'Następny »',
];
