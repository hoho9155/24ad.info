<?php 

return [
    'password' => 'Hasła muszą mieć co najmniej osiem znaków i pasować do potwierdzenia.',
    'reset' => 'Twoje hasło zostało zresetowane!',
    'sent' => 'Wysłaliśmy e-mail z linkiem do resetowania hasła!',
    'token' => 'Ten token resetowania hasła jest nieprawidłowy.',
    'user' => 'Nie możemy znaleźć użytkownika o tym adresie e-mail.',
    'throttled' => 'Please wait before retrying.',
];
