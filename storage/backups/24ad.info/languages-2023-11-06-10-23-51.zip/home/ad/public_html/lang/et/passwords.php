<?php 

return [
    'password' => 'Paroolid peavad koosnema vähemalt kaheksast tähemärgist ja ühtima kinnitusega.',
    'reset' => 'Teie parool on lähtestatud!',
    'sent' => 'Saatsime teie parooli lähtestamise lingi e-kirjaga!',
    'token' => 'See parooli lähtestamise luba on kehtetu.',
    'user' => 'Me ei leia selle e-posti aadressiga kasutajat.',
    'throttled' => 'Please wait before retrying.',
];
