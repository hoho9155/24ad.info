<?php 

return [
    'password' => 'Gesla morajo vsebovati najmanj osem znakov in se ujemati s potrditvijo.',
    'reset' => 'Vaše geslo je bilo ponastavljeno!',
    'sent' => 'Po e-pošti smo vam poslali povezavo za ponastavitev gesla!',
    'token' => 'Ta žeton za ponastavitev gesla ni veljaven.',
    'user' => 'Ne najdemo uporabnika s tem e-poštnim naslovom.',
    'throttled' => 'Please wait before retrying.',
];
