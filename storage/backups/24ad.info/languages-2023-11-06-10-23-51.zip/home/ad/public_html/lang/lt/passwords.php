<?php 

return [
    'password' => 'Slaptažodžiai turi būti sudaryti iš mažiausiai aštuonių simbolių ir sutapti su patvirtinimu.',
    'reset' => 'Jūsų slaptažodis nustatytas iš naujo!',
    'sent' => 'Jūsų slaptažodžio nustatymo iš naujo nuorodą išsiuntėme el. paštu!',
    'token' => 'Šis slaptažodžio nustatymo iš naujo prieigos raktas yra neteisingas',
    'user' => 'Negalime rasti vartotojo su šiuo el. pašto adresu.',
    'throttled' => 'Please wait before retrying.',
];
