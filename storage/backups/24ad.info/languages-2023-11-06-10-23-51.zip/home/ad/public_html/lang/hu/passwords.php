<?php 

return [
    'password' => 'A jelszavaknak legalább nyolc karakterből kell állniuk, és egyeznie kell a megerősítéssel.',
    'reset' => 'A jelszavad vissza lett állítva!',
    'sent' => 'E-mailben elküldtük a jelszó-visszaállítási linket!',
    'token' => 'Ez a jelszó-visszaállítási token érvénytelen.',
    'user' => 'Nem találunk felhasználót ezzel az e-mail címmel.',
    'throttled' => 'Please wait before retrying.',
];
