<?php 

return [
    'password' => 'Parolēm ir jābūt vismaz astoņām rakstzīmēm un jāatbilst apstiprinājuma datiem.',
    'reset' => 'Jūsu parole ir atiestatīta!',
    'sent' => 'Mēs esam nosūtījuši jūsu paroles atiestatīšanas saiti pa e-pastu!',
    'token' => 'Šī paroles atiestatīšanas pilnvara nav derīga.',
    'user' => 'Mēs nevaram atrast lietotāju ar šo e-pasta adresi.',
    'throttled' => 'Please wait before retrying.',
];
