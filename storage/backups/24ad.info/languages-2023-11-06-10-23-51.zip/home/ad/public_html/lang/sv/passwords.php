<?php 

return [
    'password' => 'Lösenorden måste vara minst åtta tecken och matcha bekräftelsen.',
    'reset' => 'Ditt lösenord har blivit återställt!',
    'sent' => 'Vi har skickat din länk för återställning av lösenord via e-post!',
    'token' => 'Denna lösenordsåterställningstoken är ogiltig.',
    'user' => 'Vi kan inte hitta en användare med den e-postadressen.',
    'throttled' => 'Please wait before retrying.',
];
