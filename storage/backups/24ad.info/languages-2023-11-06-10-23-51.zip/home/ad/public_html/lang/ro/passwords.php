<?php 

return [
    'password' => 'Parola trebuie să conțină minim 8 caractere și trebuie să corespundă cu parola confirmată.',
    'reset' => 'Parola a fost resetată!',
    'sent' => 'Link-ul pentru resetarea parolei a fost trimis pe adresa de email!',
    'token' => 'Token-ul pentru resetarea parolei este invalid.',
    'user' => 'Nu există utilizator cu această adresă de email.',
    'throttled' => 'Please wait before retrying.',
];
