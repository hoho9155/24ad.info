<?php 

return [
    'password' => 'Şifreler en az sekiz karakter olmalı ve onay ile eşleşmelidir.',
    'reset' => 'Your password has been reset!',
    'sent' => 'We have e-mailed your password reset link!',
    'token' => 'This password reset token is invalid.',
    'user' => 'We can\'t find a user with that e-mail address.',
    'throttled' => 'Please wait before retrying.',
];
