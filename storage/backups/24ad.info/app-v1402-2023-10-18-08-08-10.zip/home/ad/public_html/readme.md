## LaraClassifier - Classified Ads Web Application

LaraClassifier is a Classified CMS, a powerfull modulable app and has a fully responsive design. Built with Laravel and Bootstrap. It is packed with lots of features.


## Installation & Update Documentation

The documentation is located in the folder: documentation/


## License

This software is furnished under a license and may be used and copied only in accordance with the terms of such license and with the inclusion of the above copyright notice. If you Purchased from CodeCanyon, Please read the full License from here : https://codecanyon.net/licenses/standard
